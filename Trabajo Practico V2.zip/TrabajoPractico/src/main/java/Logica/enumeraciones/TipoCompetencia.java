package Logica.enumeraciones;

public enum TipoCompetencia {
	Actitudinal, Tecnica
}

package Logica.enumeraciones;

public enum EstadoCuestionario {
	Activo, EnProceso, Completo, SinContestar
}

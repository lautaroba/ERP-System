package Logica.enumeraciones;

public enum TipoRespuesta {
	MultipleOpcion, VerdaderoOFalso
}

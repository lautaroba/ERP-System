package Logica.gestores;

public class GestorCuestionario {

}

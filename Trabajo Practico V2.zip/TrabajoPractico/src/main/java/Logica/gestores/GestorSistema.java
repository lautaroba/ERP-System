package Logica.gestores;

public class GestorSistema {

}

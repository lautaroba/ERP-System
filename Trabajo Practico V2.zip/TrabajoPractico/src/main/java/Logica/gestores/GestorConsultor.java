package Logica.gestores;

public class GestorConsultor {

}

package BaseDeDatos.MySQL;

import BaseDeDatos.Conexion.Sesion;
import Logica.entidades.Competencia;

public class CompetenciaMySQL {
	
	public static void CrearCompetencia(Competencia c) {
		Sesion.entity.getTransaction().begin();
		Sesion.entity.persist(c);
		Sesion.entity.getTransaction().commit();
	}
	public void ModificarCompetencia(Competencia c) {
		// TODO Auto-generated method stub

	}
	public void EliminarCompetencia(Competencia c) {
		// TODO Auto-generated method stub

	}
	public Competencia BuscarCompetencia(Competencia c) {
		return Sesion.entity.find(Competencia.class, c.getCodigo());
	}
	
}

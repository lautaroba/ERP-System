package Programa;

import Logica.gestores.*;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;

public class App extends Application {
	
	public static GestorPuesto gestorPuesto;
	public static GestorCompetencia gestorCompetencia;
	
	@Override
	public void start(Stage stage) throws Exception{

		try {
			AnchorPane root = FXMLLoader.load(getClass().getResource("Login.fxml"));
			Scene scene = new Scene(root);
			stage.setTitle("Capit@l humano - Nuevo Puesto");
			stage.setScene(scene);
			stage.show();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public static void main(String[] args) {
		launch(args);
		try {
			gestorPuesto = new GestorPuesto();
			gestorCompetencia = new GestorCompetencia();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}